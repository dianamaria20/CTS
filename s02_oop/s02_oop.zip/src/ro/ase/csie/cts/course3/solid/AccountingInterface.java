package ro.ase.csie.cts.course3.solid;

public interface AccountingInterface {
	public abstract void payTuition(Student student);
}
