package ro.ase.csie.cts.course3.solid;

public class Accounting2 implements AccountingInterface {

	@Override
	public void payTuition(Student student) {
		
	}

}
