package ro.ase.csie.cts.course3.solid;

public class Accounting implements AccountingInterface {
	public void payTuition(Student student) {}
}
