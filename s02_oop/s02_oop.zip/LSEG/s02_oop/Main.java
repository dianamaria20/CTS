package s02_oop;

import java.util.ArrayList;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Solution solution2 = new Solution();
		String s1 = "abccbd";
		int[] vector = {0,1,2,3,4,5};
		int result = solution2.solution(s1,vector);
		System.out.println(result);
	}

}
